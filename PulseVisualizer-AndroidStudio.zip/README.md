# Pulse Visualizer

Android Studio project for a customizable music visualizer.

## Current build

- Detects Android media sessions after Notification Access is enabled.
- Reads title, artist and artwork metadata.
- Shows a live animated visualizer.
- Provides a full-screen visualizer.
- Designed to support Spotify, YouTube, YouTube Music, VLC, Samsung Music and compatible modded players through Android media sessions.

## Next phase

- Exact source/app picker with persistent selection.
- Real FFT/audio-reactive visualization.
- Playback controls through MediaController.
- Home-screen widget.
- Visualizer presets and customization.
- Playback capture permission flow.

## Important

Android playback capture is subject to the source app's capture policy. Some apps may not allow their audio to be captured, even though their media metadata can still be read.
